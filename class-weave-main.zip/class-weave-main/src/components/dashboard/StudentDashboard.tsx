import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/enhanced-button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  Trophy,
  Target,
  Play
} from 'lucide-react';

const StudentDashboard: React.FC = () => {
  // Mock data - would come from localStorage/API
  const stats = {
    enrolledCourses: 4,
    completedAssignments: 12,
    overallProgress: 68,
    upcomingDeadlines: 3
  };

  const enrolledCourses = [
    {
      id: 1,
      title: 'Advanced React Development',
      instructor: 'Dr. Sarah Johnson',
      progress: 75,
      nextDeadline: 'Assignment due in 3 days',
      status: 'active'
    },
    {
      id: 2,
      title: 'JavaScript Fundamentals',
      instructor: 'Prof. Mike Chen',
      progress: 90,
      nextDeadline: 'Quiz tomorrow',
      status: 'active'
    },
    {
      id: 3,
      title: 'UI/UX Design Principles',
      instructor: 'Dr. Lisa Wang',
      progress: 45,
      nextDeadline: 'Project due next week',
      status: 'active'
    },
    {
      id: 4,
      title: 'Database Management',
      instructor: 'Prof. John Smith',
      progress: 100,
      nextDeadline: 'Course completed',
      status: 'completed'
    }
  ];

  const upcomingDeadlines = [
    { title: 'React Assignment #3', course: 'Advanced React', dueDate: 'Tomorrow', priority: 'high' },
    { title: 'JavaScript Quiz', course: 'JS Fundamentals', dueDate: 'In 2 days', priority: 'medium' },
    { title: 'Design Project', course: 'UI/UX Design', dueDate: 'Next week', priority: 'low' }
  ];

  const recentAnnouncements = [
    { title: 'New React Hooks Tutorial Available', course: 'Advanced React', time: '2 hours ago' },
    { title: 'Quiz Schedule Updated', course: 'JavaScript Fundamentals', time: '1 day ago' },
    { title: 'Guest Lecture Next Week', course: 'UI/UX Design', time: '2 days ago' }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-student rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Welcome back, Alex!</h1>
        <p className="text-white/90">
          You have {stats.upcomingDeadlines} upcoming deadlines and you're {stats.overallProgress}% through your current courses.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Enrolled Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-student">{stats.enrolledCourses}</div>
            <p className="text-xs text-muted-foreground">
              1 completed this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assignments Done</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-student">{stats.completedAssignments}</div>
            <p className="text-xs text-muted-foreground">
              +3 this week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Progress</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-student">{stats.overallProgress}%</div>
            <p className="text-xs text-muted-foreground">
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Deadlines</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-student">{stats.upcomingDeadlines}</div>
            <p className="text-xs text-muted-foreground">
              This week
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* My Courses */}
        <Card>
          <CardHeader>
            <CardTitle>My Courses</CardTitle>
            <CardDescription>Your enrolled courses and progress</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {enrolledCourses.map((course) => (
              <div key={course.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium truncate">{course.title}</h4>
                  <p className="text-sm text-muted-foreground">{course.instructor}</p>
                  <div className="mt-2">
                    <Progress value={course.progress} className="h-1" />
                    <span className="text-xs text-muted-foreground mt-1 block">
                      {course.progress}% complete
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={course.status === 'completed' ? 'default' : 'secondary'}>
                      {course.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {course.nextDeadline}
                    </span>
                  </div>
                </div>
                <Button variant="student" size="sm">
                  <Play className="h-4 w-4 mr-2" />
                  Continue
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Upcoming Deadlines */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Deadlines</CardTitle>
            <CardDescription>Don't miss these important dates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingDeadlines.map((deadline, index) => (
              <div key={index} className="flex items-center gap-3 p-3 border border-border rounded-lg">
                <div className={`w-3 h-3 rounded-full ${
                  deadline.priority === 'high' ? 'bg-destructive' :
                  deadline.priority === 'medium' ? 'bg-warning' : 'bg-student'
                }`} />
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm">{deadline.title}</h4>
                  <p className="text-xs text-muted-foreground">{deadline.course}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{deadline.dueDate}</p>
                  <Badge variant={
                    deadline.priority === 'high' ? 'destructive' :
                    deadline.priority === 'medium' ? 'secondary' : 'outline'
                  } className="text-xs">
                    {deadline.priority}
                  </Badge>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" size="sm">
              <Calendar className="h-4 w-4 mr-2" />
              View Calendar
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Announcements */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Announcements</CardTitle>
          <CardDescription>Latest updates from your instructors</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentAnnouncements.map((announcement, index) => (
            <div key={index} className="flex items-start gap-3 p-3 border border-border rounded-lg">
              <div className="w-2 h-2 bg-student rounded-full mt-2" />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-sm">{announcement.title}</h4>
                <p className="text-xs text-muted-foreground">{announcement.course}</p>
                <p className="text-xs text-muted-foreground mt-1">{announcement.time}</p>
              </div>
            </div>
          ))}
          <Button variant="outline" className="w-full" size="sm">
            View All Announcements
          </Button>
        </CardContent>
      </Card>

      {/* Achievement Section */}
      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
          <CardDescription>Keep up the great work!</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border border-border rounded-lg">
              <Trophy className="h-8 w-8 text-student mx-auto mb-2" />
              <p className="text-sm font-medium">Course Completed</p>
              <p className="text-xs text-muted-foreground">Database Management</p>
            </div>
            <div className="text-center p-4 border border-border rounded-lg">
              <Target className="h-8 w-8 text-student mx-auto mb-2" />
              <p className="text-sm font-medium">68% Average</p>
              <p className="text-xs text-muted-foreground">Across all courses</p>
            </div>
            <div className="text-center p-4 border border-border rounded-lg">
              <CheckCircle className="h-8 w-8 text-student mx-auto mb-2" />
              <p className="text-sm font-medium">12 Assignments</p>
              <p className="text-xs text-muted-foreground">Completed this month</p>
            </div>
            <div className="text-center p-4 border border-border rounded-lg">
              <Clock className="h-8 w-8 text-student mx-auto mb-2" />
              <p className="text-sm font-medium">45 Hours</p>
              <p className="text-xs text-muted-foreground">Study time logged</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentDashboard;