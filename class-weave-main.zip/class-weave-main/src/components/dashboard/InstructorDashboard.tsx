import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/enhanced-button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Users, 
  BookOpen, 
  TrendingUp, 
  MessageSquare, 
  Plus,
  Calendar,
  Clock,
  Star
} from 'lucide-react';

const InstructorDashboard: React.FC = () => {
  // Mock data - would come from localStorage/API
  const stats = {
    totalCourses: 8,
    totalStudents: 247,
    completionRate: 78,
    newMessages: 12
  };

  const courses = [
    {
      id: 1,
      title: 'Advanced React Development',
      students: 45,
      status: 'published',
      progress: 85,
      lastUpdated: '2 days ago'
    },
    {
      id: 2,
      title: 'JavaScript Fundamentals',
      students: 67,
      status: 'published',
      progress: 92,
      lastUpdated: '1 week ago'
    },
    {
      id: 3,
      title: 'TypeScript Mastery',
      students: 23,
      status: 'draft',
      progress: 45,
      lastUpdated: '3 days ago'
    }
  ];

  const recentActivity = [
    { type: 'submission', student: 'Alice Johnson', course: 'React Development', time: '2 hours ago' },
    { type: 'question', student: 'Bob Smith', course: 'JavaScript Fundamentals', time: '4 hours ago' },
    { type: 'completion', student: 'Carol Davis', course: 'React Development', time: '1 day ago' }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-instructor rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Welcome back, Dr. Johnson!</h1>
        <p className="text-white/90">
          You have {stats.newMessages} new messages and {stats.totalStudents} active students across your courses.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-instructor">{stats.totalCourses}</div>
            <p className="text-xs text-muted-foreground">
              +2 from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-instructor">{stats.totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              +18 from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-instructor">{stats.completionRate}%</div>
            <p className="text-xs text-muted-foreground">
              +5% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-instructor">{stats.newMessages}</div>
            <p className="text-xs text-muted-foreground">
              Respond to urgent messages
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Course Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>My Courses</CardTitle>
                <CardDescription>Manage your active courses</CardDescription>
              </div>
              <Button variant="instructor" size="sm">
                <Plus className="h-4 w-4 mr-2" />
                New Course
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {courses.map((course) => (
              <div key={course.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium truncate">{course.title}</h4>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-sm text-muted-foreground">
                      {course.students} students
                    </span>
                    <Badge variant={course.status === 'published' ? 'default' : 'secondary'}>
                      {course.status}
                    </Badge>
                  </div>
                  <div className="mt-2">
                    <Progress value={course.progress} className="h-1" />
                    <span className="text-xs text-muted-foreground mt-1 block">
                      {course.progress}% complete • Updated {course.lastUpdated}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest student interactions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 bg-instructor rounded-full mt-2" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <span className="font-medium">{activity.student}</span>
                    {activity.type === 'submission' && ' submitted assignment in '}
                    {activity.type === 'question' && ' asked a question in '}
                    {activity.type === 'completion' && ' completed module in '}
                    <span className="font-medium">{activity.course}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" size="sm">
              View All Activity
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Plus className="h-5 w-5" />
              <span className="text-sm">Create Course</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Calendar className="h-5 w-5" />
              <span className="text-sm">Schedule Class</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              <span className="text-sm">Send Announcement</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Star className="h-5 w-5" />
              <span className="text-sm">Grade Assignments</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InstructorDashboard;