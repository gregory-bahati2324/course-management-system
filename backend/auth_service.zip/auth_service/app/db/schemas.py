from pydantic import BaseModel, EmailStr
from typing import Optional, Union
from uuid import UUID
from enum import Enum

class UserRole(str, Enum):
    STUDENT = "student"
    INSTRUCTOR = "instructor"
    ADMIN = "admin"

class UserBase(BaseModel):
    email: EmailStr
    role: UserRole

class UserCreate(UserBase):
    password: str
    full_name: str
    student_id: Optional[str] = None
    year_of_study: Optional[str] = None

class AdminProfile(BaseModel):
    full_name: str
    permission: Optional[str] = None

class InstructorProfile(BaseModel):
    full_name: str
    department: Optional[str] = None
    bio: Optional[str] = None

class StudentProfile(BaseModel):
    full_name: str
    student_id: str
    year_of_study: str

class UserOut(BaseModel):
    id: UUID
    is_active: bool
    profile: Union[AdminProfile, InstructorProfile, StudentProfile]

    model_config = {"from_attributes": True}

class UpdateUser(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    role: Optional[UserRole] = None
    password: Optional[str] = None

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None
