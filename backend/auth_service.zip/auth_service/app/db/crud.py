from sqlalchemy.orm import Session
from uuid import UUID
from app.db import schemas
from app.models import user as models
from fastapi import HTTPException, Depends, status



def get_user_by_email(db: Session, email: str):
    """Return a user object by email."""
    return db.query(models.User).filter(models.User.email == email).first()


def create_user(db: Session, sign_user: schemas.UserCreate):
    """Create a new user and their profile, then return user+profile."""
    # Create main user record
    from app.core.security import get_password_hash, verify_password
    db_user = models.User(
        email=sign_user.email,
        password_hash=get_password_hash(sign_user.password),
        role=sign_user.role,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    # Create profile record
    if sign_user.role == schemas.UserRole.ADMIN:
        profile = models.AdminProfile(
            id=db_user.id,
            full_name=sign_user.full_name
        )
    elif sign_user.role == schemas.UserRole.INSTRUCTOR:
        profile = models.InstructorProfile(
            id=db_user.id,
            full_name=sign_user.full_name
        )
    else:  # Student
        existing_student = db.query(models.StudentProfile).filter(
            models.StudentProfile.student_id == sign_user.student_id
        ).first()
        if existing_student:
            raise HTTPException(status_code=403, detail="student_id already exists")
        profile = models.StudentProfile(
            id=db_user.id,
            full_name=sign_user.full_name,
            student_id=sign_user.student_id,
            year_of_study=sign_user.year_of_study or "1"
        )

    db.add(profile)
    db.commit()
    db.refresh(profile)

    return {"id": db_user.id, "is_active": db_user.is_active, "profile": profile}


def authenticate_user(db: Session, email: str, password: str):
    """Check user credentials and return user object if valid."""
    from app.core.security import get_password_hash, verify_password
    db_user = get_user_by_email(db, email)
    if not db_user:
        return None
    if not verify_password(password, db_user.password_hash):
        return None
    return db_user


def update_user(db: Session, user_id: UUID, update_data: schemas.UpdateUser):
    """Update user info and return dict including profile."""
    from app.core.security import get_password_hash, verify_password
    db_user = db.query(models.User).filter(models.User.id == str(user_id)).first()
    if not db_user:
        return None

    update_dict = update_data.model_dump(exclude_unset=True)

    # Handle password update
    if "password" in update_dict:
        update_dict["password_hash"] = get_password_hash(update_dict.pop("password"))

    # Update attributes
    for key, value in update_dict.items():
        if key != "full_name":  # full_name goes to profile
            setattr(db_user, key, value)

    db.commit()
    db.refresh(db_user)

    # Update profile full_name if provided
    profile = None
    if db_user.role == schemas.UserRole.ADMIN:
        profile = db.query(models.AdminProfile).filter(models.AdminProfile.id == db_user.id).first()
    elif db_user.role == schemas.UserRole.INSTRUCTOR:
        profile = db.query(models.InstructorProfile).filter(models.InstructorProfile.id == db_user.id).first()
    else:
        profile = db.query(models.StudentProfile).filter(models.StudentProfile.id == db_user.id).first()

    if "full_name" in update_dict and profile:
        profile.full_name = update_dict["full_name"]
        db.commit()
        db.refresh(profile)

    return {"id": db_user.id, "is_active": db_user.is_active, "profile": profile}


def delete_user(db: Session, user_id: UUID):
    """Delete a user."""
    db_user = db.query(models.User).filter(models.User.id == str(user_id)).first()
    if not db_user:
        return False
    db.delete(db_user)
    db.commit()
    return True


def get_all_users(db: Session, skip: int = 0, limit: int = 100):
    """Return all users with their profiles."""
    users = db.query(models.User).offset(skip).limit(limit).all()
    result = []
    for user in users:
        if user.role == schemas.UserRole.ADMIN:
            profile = db.query(models.AdminProfile).filter(models.AdminProfile.id == user.id).first()
        elif user.role == schemas.UserRole.INSTRUCTOR:
            profile = db.query(models.InstructorProfile).filter(models.InstructorProfile.id == user.id).first()
        else:
            profile = db.query(models.StudentProfile).filter(models.StudentProfile.id == user.id).first()
        result.append({"id": user.id, "is_active": user.is_active, "profile": profile})
    return result


def get_user_with_profile(db: Session, user_id: UUID):
    """Get a single user and their profile."""
    user = db.query(models.User).filter(models.User.id == str(user_id)).first()
    if not user:
        return None

    if user.role == schemas.UserRole.ADMIN:
        profile = db.query(models.AdminProfile).filter(models.AdminProfile.id == user.id).first()
    elif user.role == schemas.UserRole.INSTRUCTOR:
        profile = db.query(models.InstructorProfile).filter(models.InstructorProfile.id == user.id).first()
    else:
        profile = db.query(models.StudentProfile).filter(models.StudentProfile.id == user.id).first()

    return {"id": user.id, "is_active": user.is_active, "profile": profile}
