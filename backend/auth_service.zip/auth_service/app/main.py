from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth
from app.db.database import Base, engine
from app.models import user  # ensure models are imported

# Create tables (dev)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Auth Service",
    description="Handles user signin and signup",
    version="1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],     # tighten this in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["auth"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8004)
