import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import InstructorDashboard from '@/components/dashboard/InstructorDashboard';
import StudentDashboard from '@/components/dashboard/StudentDashboard';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="h-screen flex bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto">
          {user?.role === 'instructor' ? (
            <InstructorDashboard />
          ) : (
            <StudentDashboard />
          )}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;