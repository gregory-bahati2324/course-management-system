from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from datetime import timedelta
from typing import Annotated, List
from uuid import UUID
from sqlalchemy.orm import Session

from app.core.security import create_access_token, get_current_user
from app.core.config import settings
from app.db import schemas, crud
from app.db.database import get_db

router = APIRouter()

@router.post("/signup", response_model=schemas.UserOut)
async def signup(user_data: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user_data.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, sign_user=user_data)

@router.get("/users/me", response_model=schemas.UserOut)
async def get_me(current_user: schemas.UserOut = Depends(get_current_user), db: Session = Depends(get_db)):
    user = crud.get_user_with_profile(db, current_user.id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    db_user = crud.authenticate_user(db, form_data.username, form_data.password)
    if not db_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password")

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(data={"sub": db_user.email}, expire_delta=access_token_expires)
    return {"access_token": access_token, "token_type": "bearer", "user_id": str(db_user.id)}

@router.get("/users", response_model=List[schemas.UserOut])
async def get_all_users(
    current_user: Annotated[schemas.UserOut, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100
):
    if str(current_user.role) != "admin":
        raise HTTPException(status_code=403, detail="Only admin users can access this endpoint")
    return crud.get_all_users(db, skip=skip, limit=limit)

@router.put("/users/{user_id}", response_model=schemas.UserOut)
async def update_user(
    user_id: UUID,
    update_data: schemas.UpdateUser,
    current_user: Annotated[schemas.UserOut, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    if str(current_user.id) != str(user_id) and str(current_user.role) != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You can only update your own profile (unless you're admin)")
    updated_user = crud.update_user(db, user_id, update_data)
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user

@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: UUID,
    current_user: Annotated[schemas.UserOut, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    if str(current_user.id) != str(user_id) and str(current_user.role) != "admin":
        raise HTTPException(status_code=403, detail="You can only delete your own account")
    if not crud.delete_user(db, user_id):
        raise HTTPException(status_code=404, detail="User not found")
    return
